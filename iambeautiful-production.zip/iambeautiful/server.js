const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const sharp = require('sharp');

const app = express();
const PORT = process.env.PORT || 3000;

// ═══════════════════════════════════════════
// STATIC FILES - serve the website
// ═══════════════════════════════════════════
app.use(express.static('public', {
  maxAge: '7d',
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
    if (filePath.match(/\.(jpg|jpeg|png|webp)$/)) {
      res.setHeader('Cache-Control', 'public, max-age=604800, immutable');
    }
  }
}));

app.use(express.json({ limit: '50mb' }));

// ═══════════════════════════════════════════
// CMS ADMIN - serve the admin panel
// ═══════════════════════════════════════════
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin', 'index.html'));
});
app.use('/admin', express.static('admin'));

// ═══════════════════════════════════════════
// IMAGE UPLOAD API - for CMS
// ═══════════════════════════════════════════
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB max
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Only image files allowed'), false);
  }
});

// Upload & optimize image
app.post('/api/upload', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    
    const { gallery, slot } = req.body;
    
    // Determine dimensions based on gallery type
    const configs = {
      'homepage':  { w: 480, h: 640, quality: 78, dir: 'img/homepage' },
      'lashes':    { w: 600, h: 600, quality: 78, dir: 'img/lashes' },
      'brows':     { w: 1200, h: 675, quality: 82, dir: 'img/brows' },
      'about':     { w: 600, h: 800, quality: 82, dir: 'img' },
      'hero':      { w: 1920, h: 1080, quality: 85, dir: 'img' },
      'logo':      { w: 400, h: 400, quality: 90, dir: 'img' },
    };
    
    const config = configs[gallery] || configs['homepage'];
    const filename = slot || `${gallery}-${Date.now()}.jpg`;
    const outPath = path.join(__dirname, 'public', config.dir, filename);
    
    // Ensure directory exists
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    
    // Process with sharp: resize, crop, optimize
    await sharp(req.file.buffer)
      .resize(config.w, config.h, { fit: 'cover', position: 'attention' })
      .jpeg({ quality: config.quality, progressive: true })
      .toFile(outPath);
    
    const stats = fs.statSync(outPath);
    
    res.json({ 
      success: true, 
      path: `${config.dir}/${filename}`,
      size: `${Math.round(stats.size / 1024)}KB`
    });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// List images in a gallery
app.get('/api/images/:gallery', (req, res) => {
  const dirs = {
    homepage: 'public/img/homepage',
    lashes: 'public/img/lashes',
    brows: 'public/img/brows',
  };
  const dir = dirs[req.params.gallery];
  if (!dir) return res.status(404).json({ error: 'Gallery not found' });
  
  try {
    const files = fs.readdirSync(path.join(__dirname, dir))
      .filter(f => f.match(/\.(jpg|jpeg|png|webp)$/i))
      .map(f => ({
        name: f,
        path: `${dir.replace('public/', '')}/${f}`,
        size: `${Math.round(fs.statSync(path.join(__dirname, dir, f)).size / 1024)}KB`
      }));
    res.json({ gallery: req.params.gallery, images: files });
  } catch (err) {
    res.json({ gallery: req.params.gallery, images: [] });
  }
});

// Delete an image
app.delete('/api/images/:gallery/:filename', (req, res) => {
  const dirs = { homepage: 'public/img/homepage', lashes: 'public/img/lashes', brows: 'public/img/brows' };
  const dir = dirs[req.params.gallery];
  if (!dir) return res.status(404).json({ error: 'Gallery not found' });
  
  const filePath = path.join(__dirname, dir, req.params.filename);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
    res.json({ success: true });
  } else {
    res.status(404).json({ error: 'File not found' });
  }
});

// ═══════════════════════════════════════════
// HEALTH CHECK (for Railway/Vercel)
// ═══════════════════════════════════════════
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

// ═══════════════════════════════════════════
// START
// ═══════════════════════════════════════════
app.listen(PORT, () => {
  console.log(`✦ I Am Beautiful by Mia — running on port ${PORT}`);
  console.log(`  Website: http://localhost:${PORT}`);
  console.log(`  CMS Admin: http://localhost:${PORT}/admin`);
});
