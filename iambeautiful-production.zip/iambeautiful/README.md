# I Am Beautiful by Mia — Website

Premium beauty services website with CMS admin panel.

---

## 🚀 Deploy to Railway (Recommended — Easiest)

Railway is the simplest option. $5/mo, handles everything.

### Step 1: Create a GitHub repo
1. Go to [github.com/new](https://github.com/new) and create a new repo (private is fine)
2. Upload all the files from this folder to the repo

### Step 2: Deploy on Railway
1. Go to [railway.app](https://railway.app) and sign in with GitHub
2. Click **"New Project"** → **"Deploy from GitHub Repo"**
3. Select your repo
4. Railway auto-detects Node.js and deploys. Done.

### Step 3: Add your custom domain
1. In Railway, go to your project → **Settings** → **Domains**
2. Click **"Add Custom Domain"** and enter your domain (e.g., `iambeautifulbymia.com`)
3. Railway gives you DNS records — add them at your domain registrar
4. SSL is automatic

### That's it. Your site is live at:
- **Website:** `yourdomain.com`
- **CMS Admin:** `yourdomain.com/admin`

---

## Alternative: Deploy to Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. Run `vercel` in this folder
3. Follow prompts, add custom domain in dashboard
4. Note: For CMS uploads to persist, you'll need Vercel Blob storage

---

## Alternative: Deploy to DigitalOcean

1. Create a $6/mo Droplet (Ubuntu)
2. SSH in, install Node.js 18+
3. Clone your repo, run `npm install && npm start`
4. Use PM2 to keep it running: `pm2 start server.js`
5. Point your domain's A record to the Droplet IP

---

## 📁 Project Structure

```
iambeautiful/
├── server.js              # Node.js server (Express)
├── package.json           # Dependencies
├── public/                # Website files (served to visitors)
│   ├── index.html         # Main website (all 6 pages)
│   └── img/
│       ├── homepage/      # Homepage gallery (6 portraits, 480x640)
│       ├── lashes/        # Lash gallery (5 squares, 600x600)
│       └── brows/         # PMU slider (5 landscapes, 1200x675)
└── admin/
    └── index.html         # CMS admin panel
```

## 🖼 CMS API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/upload` | Upload & auto-optimize an image |
| GET | `/api/images/:gallery` | List images (homepage, lashes, brows) |
| DELETE | `/api/images/:gallery/:file` | Delete an image |

### Upload example:
```bash
curl -X POST http://localhost:3000/api/upload \
  -F "image=@photo.jpg" \
  -F "gallery=brows" \
  -F "slot=brow-1.jpg"
```

---

## 🔧 Local Development

```bash
npm install
npm start
# Open http://localhost:3000
# Admin at http://localhost:3000/admin
```

---

## 📋 To replicate for a new client

1. Duplicate this folder
2. Replace images in `public/img/`
3. Edit `public/index.html` — change business name, services, prices, colors
4. Deploy to a new Railway project
5. Add client's domain

---

## ✨ Features

- 6-page single-file site (Home, Lashes, Brows/PMU, Laser, Skin, About)
- Cinematic page transitions with dark overlay crossfade
- Scroll parallax, 3D card tilt, word-by-word text reveals
- Animated stat counters, drag-to-scroll galleries
- Blur-to-sharp image reveal animations
- Ken Burns cinematic drift on PMU slider
- Horizontal parallax on homepage gallery
- Full mobile responsive
- CMS admin with image upload & auto-optimization
- Express server with Sharp image processing
